<!DOCTYPE html>
<html>
<head>
  <title> Lab3 - PHP Introduction </title>
  <meta charset="utf-8"/>
 <!-- <link rel="stylesheet" type="text/css" href="style5.css" > -->
 <style>
 
 
  .styling{
    margin:20px;
    border-style: dotted;
    border-color:black;
    border-width:3px;
    background-color: silver;
    padding-left: 20px;
  }
  .blue{
    color: blue;
    font-size: 1.5em;
  }
  
 
 
  
 
  </style>

</head>
<body>

<?php
$a = rand(1,10);
$b = rand(1,10);
$h = rand(1,10);
$area= 0.5*($a+$b)*$h;

?>
    <!-- coding for task 1-->
<div class="styling">
  <h1> LAB 3 </h1>
  <h1> <span style="color:red;"> Jaleel Ahmad Sayal </span> </h1>
  <hr/>

  <h2> Task 1: Area Formula Demo </h2>
  <p>
    Area of Trapizoid is <span class="sblue"> Area = 0.5 * (a+b) *h </h2>
  </p>
  <h3> Example </h3>
  <p>
    <span class="blue" > <?php echo"a= \t" ,$a; echo"b=" ,$b; echo"h=" ,$h;  echo "0.5*($a+$b)*$h" ;  ?>  </span>
  </p>
  <p>
     <span class="blue" > <?php echo "area" , $area ?> </span>
  </p>
  <p>
    <span class="blue" > area =32.5 </span>
  </p>
</div>
  <!-- coding for task 2 -->

  <div class="styling">
<h2> Task 2: Rick Roll  </h2>
<p> Click for a funny cat video! </p>
<p>
  <!--<a href= "https://www.youtube.com/watch?v=dQw4w9WgXcQ" target="_blank"> <img src= "https://tinyurl.com/ybafqu2h">   </a>-->
 <?php
  $random = rand(1,2);
  

    if ($random == 1)
      {
      echo'<a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"target="blank" ><img src= "https://tinyurl.com/ybafqu2h" /> </a>';
	  
       }
	   else{
		  
		   echo'<a href="https://www.youtube.com/watch?v=oqNKD9YVe4U"target="blank"><img src="https://tinyurl.com/ybafqu2h"alt="funny cat video"/></a> ';
	   }
   ?>

</p>
</div>

<!-- Coding for task 3-->



<div class="styling">
<h2> Task 3: Style Modification </h2>
<p>
<?php
$random=rand(1,3);
$colorone="blue";
$colortwo="red";
$colorthree="green";
$random2=rand(1,3);
$font_size1="0.5em";
$font_size2="1em";
$font_size3="3em";


	if($random==1){
		$color = $colorone;
  
	}
	else if($random==2){
		$color=$colortwo;
	
	}
	else
	{
		$color=$colorthree;  
	}
	
	if($random2==1){
		$fontsize=$font_size1;
		
	}
	else if($random2==2){
		$fontsize=$font_size2;
		
	}
	else{
		
		$fontsize=$font_size3;
		
	}
	
print"<span style=\"color:$color; font-size:$fontsize;\"> PHP is driving me Crazy </span>";
	?>
	
	
</p>
</div>
</body>
</html>
